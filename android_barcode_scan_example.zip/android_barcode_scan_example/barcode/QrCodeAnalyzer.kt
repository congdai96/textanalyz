package it.lucapizzini.android_barcode_scan_example.barcode

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.graphics.*
import android.widget.Toast
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.lifecycle.Observer
import com.google.android.material.snackbar.Snackbar
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.common.InputImage
import it.lucapizzini.android_barcode_scan_example.view.BarcodeBoxView
import it.lucapizzini.android_barcode_scan_example.ImageUtils
import it.lucapizzini.android_barcode_scan_example.SmoothedMutableLiveData

class QrCodeAnalyzer(
    private val context: Context,
    private val barcodeBoxView: BarcodeBoxView,
    private val previewViewWidth: Float,
    private val previewViewHeight: Float
) : ImageAnalysis.Analyzer {

    /**
     * This parameters will handle preview box scaling
     */
    private var isContinue: Boolean = false
    private var brcNo = 1

    private var barcodeValue = ""
    private var scaleX = 1f
    private var scaleY = 1f

    private fun translateX(x: Float) = x * scaleX
    private fun translateY(y: Float) = y * scaleY
    private var endResult = SmoothedMutableLiveData<Boolean>(50L)
    private var toast: Toast? = null

    private fun adjustBoundingRect(rect: Rect) = RectF(
        translateX(rect.left.toFloat()),
        translateY(rect.top.toFloat()),
        translateX(rect.right.toFloat()),
        translateY(rect.bottom.toFloat())
    )

    @SuppressLint("UnsafeOptInUsageError")
    override fun analyze(image: ImageProxy) {

        val img = image.image
        if (img != null) {
            // Update scale factors
            scaleX = previewViewWidth / img.height.toFloat()
            scaleY = previewViewHeight / img.width.toFloat()

            val inputImage = InputImage.fromMediaImage(img, image.imageInfo.rotationDegrees)
            var bitmapImage = ImageUtils.convertYuv420888ImageToBitmap(img)
            imageAnalyz(bitmapImage, image)
            //image.close()

//            // Process image searching for barcodes
//            val options = BarcodeScannerOptions.Builder()
//                .build()
//
//            val scanner = BarcodeScanning.getClient(options)
//
//            scanner.process(inputImage)
//                .addOnSuccessListener { barcodes ->
//                    if (barcodes.isNotEmpty()) {
//                        isContinue = true
//                        var i = 1
//                        for (barcode in barcodes) {
//                            // Handle received barcodes...
//                                barcodeValue += " "+ i.toString() + barcode.rawValue
//                                i++
//                            // Update bounding rect
//                            barcode.boundingBox?.let { rect ->
//                                barcodeBoxView.setRect(
//                                    adjustBoundingRect(
//                                        rect
//                                    )
//                                )
//                            }
//
//
//                            //graphicOverlay.add(BarcodeGraphic(graphicOverlay, barcode))
//                        }
//
//                    } else {
//                        isContinue = false
//                        // Remove bounding rect
//                        barcodeBoxView.setRect(RectF())
//                    }
//                    if(isContinue) {
//                        var bitmapImage = ImageUtils.convertYuv420888ImageToBitmap(image.image!!)
//                        var canvas = Canvas(bitmapImage)
//                        var labelPaint = Paint()
//                        labelPaint.color = Color.WHITE
//                        labelPaint.style = Paint.Style.FILL
//                        for (i in barcodes.indices) {
//                            val barcode = barcodes[i]
//
//                            val rect = RectF(barcode.boundingBox)
////      // If the image is flipped, the left will be translated to right, and the right to left.
////      val x0 = translateX(rect.left)
////      val x1 = translateX(rect.right)
////      rect.left = min(x0, x1)
////      rect.right = max(x0, x1)
////      rect.top = translateY(rect.top)
////      rect.bottom = translateY(rect.bottom)
//                            canvas.drawRect(rect, labelPaint)
//                        }
//
//                        analyze(InputImage.fromBitmap(bitmapImage, 0))
//                    } else {
//                        Toast.makeText(
//                            context,
//                            "Value: $barcodeValue",
//                            Toast.LENGTH_SHORT
//                        )
//                            .show()
//                    }
//
//                    image.close()
//                    barcodeValue = ""
//                }
//                .addOnFailureListener { }

        }
        //image.close()

    }

    private fun imageAnalyz(bitmapImage: Bitmap, image: ImageProxy) {
        // Process image searching for barcodes
        val options = BarcodeScannerOptions.Builder()
            .build()

        val scanner = BarcodeScanning.getClient(options)

        scanner.process(InputImage.fromBitmap(bitmapImage, 0))
            .addOnSuccessListener { barcodes ->
                if (barcodes.isNotEmpty()) {
                    isContinue = true
                    for (barcode in barcodes) {
                        // Handle received barcodes...
                        barcodeValue += " "+ brcNo.toString() //+ barcode.rawValue
                        brcNo++
                        // Update bounding rect
                        barcode.boundingBox?.let { rect ->
                            barcodeBoxView.setRect(
                                adjustBoundingRect(
                                    rect
                                )
                            )
                        }


                        //graphicOverlay.add(BarcodeGraphic(graphicOverlay, barcode))
                    }

                    var bitmapImage2 = bitmapImage
                    var canvas = Canvas(bitmapImage2)
                    var labelPaint = Paint()
                    labelPaint.color = Color.WHITE
                    labelPaint.style = Paint.Style.FILL
                    for (i in barcodes.indices) {
                        val barcode = barcodes[i]

                        val rect = RectF(barcode.boundingBox)
//      // If the image is flipped, the left will be translated to right, and the right to left.
//      val x0 = translateX(rect.left)
//      val x1 = translateX(rect.right)
//      rect.left = min(x0, x1)
//      rect.right = max(x0, x1)
//      rect.top = translateY(rect.top)
//      rect.bottom = translateY(rect.bottom)
                        canvas.drawRect(rect, labelPaint)
                    }

                    imageAnalyz(bitmapImage2, image)




                } else {
                    isContinue = false
                    // Remove bounding rect
                    barcodeBoxView.setRect(RectF())

                    if(barcodeValue.isNotEmpty()){
                        if(toast != null) {
                            toast?.cancel()
                        }
                        toast = Toast.makeText(
                            context,
                            "Value: $barcodeValue",
                            Toast.LENGTH_SHORT
                        )
                        toast?.show()
                    }

                    barcodeValue = ""
                    brcNo = 1
                    image.close()

                }

                //image.close()

            }
            .addOnFailureListener { }
    }
}